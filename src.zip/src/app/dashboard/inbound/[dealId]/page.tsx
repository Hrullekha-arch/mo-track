

"use client";

import { useState, useEffect, use } from 'react';
import { doc, onSnapshot, updateDoc, arrayRemove, getDoc, arrayUnion, collection, query, where, getDocs, writeBatch, limit } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { InboundRequest, InboundItem, InboundMilestone, Order, O2DStatus, StockTransaction, PurchaseRequest, O2DProcess, PurchaseStatus } from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Barcode, CheckCircle, Circle, Ruler, Truck, Warehouse, Weight, ChevronDown, Loader2, Undo2, ScanLine, Printer } from 'lucide-react';
import { Button } from "@/components/ui/button";
import Link from 'next/link';
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { format } from 'date-fns';
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { PO_PROCESS_CONFIG, INBOUND_PROCESS_CONFIG } from '@/lib/constants';
import { updateStockQuantityAction, revertStockAdditionAction } from '@/app/dashboard/inventory/actions';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { StockLengthSticker } from "@/components/features/inventory/StockLengthSticker";


const ItemProcessTimeline = ({
    item,
    itemIndex,
    request,
    onUpdate,
    onRevert,
    userRole,
    onBarcodeClick
}: {
    item: InboundItem,
    itemIndex: number,
    request: InboundRequest,
    onUpdate: (itemIndex: number, stepId: number) => void,
    onRevert: (itemIndex: number, milestone: InboundMilestone) => void,
    userRole: string | null,
    onBarcodeClick: (item: InboundItem, itemIndex: number, stepId: number) => void;
}) => {
    return (
        <div className="pl-4 py-2">
            <div className="grid grid-cols-5 gap-4 text-center text-xs text-muted-foreground">
                {INBOUND_PROCESS_CONFIG.map(step => {
                    const milestone = item.inboundMilestones?.find(m => m.stepId === step.id);
                    const isCompleted = milestone?.status === 'completed';
                    const Icon = step.icon;

                    const isBarcodeStep = step.id === 3; // ID of the Barcode step

                    return (
                        <div key={step.id} className="flex flex-col items-center gap-1">
                            <div className="relative">
                                <button
                                    className="flex flex-col items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed group"
                                    onClick={() => {
                                        if (isBarcodeStep) {
                                            onBarcodeClick(item, itemIndex, step.id);
                                        } else {
                                            onUpdate(itemIndex, step.id);
                                        }
                                    }}
                                    disabled={isCompleted}
                                >
                                    <div className={cn(
                                        "flex h-10 w-10 items-center justify-center rounded-full border-2 transition-colors",
                                        isCompleted ? "bg-green-100 border-green-500" : "bg-card border-border group-hover:bg-muted",
                                        isBarcodeStep && "cursor-pointer hover:bg-muted"
                                    )}>
                                        <Icon className={cn("h-5 w-5 transition-colors", isCompleted ? "text-green-600" : "text-muted-foreground")} />
                                    </div>
                                </button>
                                {isCompleted && userRole === 'admin' && (
                                     <AlertDialogTrigger asChild>
                                        <Button
                                            size="icon"
                                            variant="ghost"
                                            className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-destructive/10 text-destructive hover:bg-destructive/20"
                                            onClick={() => onRevert(itemIndex, milestone)}
                                        >
                                            <Undo2 className="h-3 w-3" />
                                        </Button>
                                    </AlertDialogTrigger>
                                )}
                            </div>
                            <p className="font-medium mt-1">{step.name}</p>
                            {isCompleted && milestone?.completedAt ? (
                                <p className="text-green-600">{format(new Date(milestone.completedAt), 'dd/MM HH:mm')}</p>
                            ) : (
                                <p>{step.time}</p>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

export default function InboundProcessPage({ params: paramsPromise }: { params: Promise<{ dealId: string }> }) {
    // The dealId from the URL is now the PO Number, which is the ID of the inbound document
    const { dealId: poNumber } = use(paramsPromise);
    const [request, setRequest] = useState<InboundRequest | null>(null);
    const [loading, setLoading] = useState(true);
    const [updating, setUpdating] = useState<string | null>(null);
    const [revertingMilestone, setRevertingMilestone] = useState<{itemIndex: number, milestone: InboundMilestone} | null>(null);
    const [printingItem, setPrintingItem] = useState<InboundItem | null>(null);

    const { user, role } = useAuth();
    const { toast } = useToast();

    useEffect(() => {
        const docRef = doc(db, "inbounds", poNumber);
        const unsubscribe = onSnapshot(docRef, (doc) => {
            if (doc.exists()) {
                const data = { id: doc.id, ...doc.data() } as InboundRequest;
                if (data.items) {
                    data.items = data.items.map(item => ({ ...item, inboundMilestones: item.inboundMilestones || [] }));
                }
                setRequest(data);
            } else {
                setRequest(null);
            }
            setLoading(false);
        });

        return () => unsubscribe();
    }, [poNumber]);

     const handleStatusUpdate = async (itemIndex: number, stepId: number) => {
        if (!request || !user) return;
        const key = `${itemIndex}-${stepId}`;
        setUpdating(key);
        
        try {
            const requestRef = doc(db, "inbounds", request.id);
            // Create a deep copy of the items array to avoid mutation issues.
            const items = JSON.parse(JSON.stringify(request.items || []));
            const itemToUpdate = items[itemIndex];

            if (!itemToUpdate) throw new Error("Item not found");

            const newMilestone: InboundMilestone = {
                stepId,
                status: 'completed',
                completedAt: new Date().toISOString(),
                completedBy: user.name,
            };
            
            itemToUpdate.inboundMilestones = itemToUpdate.inboundMilestones || [];

            const existingMilestone = itemToUpdate.inboundMilestones.find((m: InboundMilestone) => m.stepId === stepId);
            if (existingMilestone) {
                toast({ variant: "destructive", title: "Step already completed for this item." });
                setUpdating(null);
                return;
            }

            itemToUpdate.inboundMilestones.push(newMilestone);
            
            const wasLastStep = stepId === INBOUND_PROCESS_CONFIG[INBOUND_PROCESS_CONFIG.length - 1].id;
            const batch = writeBatch(db);

            batch.update(requestRef, { items: items });

            toast({ title: "Process Updated", description: `${INBOUND_PROCESS_CONFIG.find(s=>s.id===stepId)?.name} marked as complete for ${itemToUpdate.itemName}.`});
            
            const itemIsNowComplete = itemToUpdate.inboundMilestones.length === INBOUND_PROCESS_CONFIG.length;
            
            if (itemIsNowComplete) {
                const stockId = itemToUpdate.itemName.replace(/\//g, '-');
                const quantity = parseFloat(itemToUpdate.quantity);
                
                // Fetch the original purchase request to get the salesman
                let salesman = 'Unknown';
                if (request.purchaseRequestId) {
                    const purchaseRequestRef = doc(db, 'purchaseRequests', request.purchaseRequestId);
                    const prDoc = await getDoc(purchaseRequestRef);
                    salesman = prDoc.exists() ? (prDoc.data() as PurchaseRequest).salesman : 'Unknown';
                }

                const transaction: Omit<StockTransaction, 'id'> = {
                    stockId: stockId,
                    bcn: itemToUpdate.itemName,
                    type: 'addition',
                    quantityChange: quantity,
                    poNumber: itemToUpdate.poNumber,
                    salesman: salesman,
                    lengths: [quantity], 
                    createdAt: new Date().toISOString(),
                    createdBy: user.name,
                };
                
                const result = await updateStockQuantityAction(stockId, transaction);
                if (result.success) {
                    toast({ title: "Stock Updated!", description: `${itemToUpdate.quantity} units of ${itemToUpdate.itemName} added to inventory.`});
                } else {
                    toast({ variant: 'destructive', title: 'Stock Update Failed', description: result.message });
                }

                const orderQuery = query(collection(db, "orders"), where("crmOrderNo", "==", request.dealId), limit(1));
                const orderSnapshot = await getDocs(orderQuery);
                if (!orderSnapshot.empty) {
                    const orderDoc = orderSnapshot.docs[0];
                    const orderRef = orderDoc.ref;
                    const orderData = orderDoc.data() as Order;
                    const fabricDetails = (orderData.fabricDetails || []).map(fabric => {
                        if (fabric.fabricName === itemToUpdate.itemName) {
                            return { ...fabric, status: 'in stock' as const };
                        }
                        return fabric;
                    });
                    batch.update(orderRef, { fabricDetails });
                }
            }

             if (wasLastStep) {
                if (!request.purchaseRequestId) {
                    toast({ variant: "destructive", title: "Missing Purchase Request", description: "Cannot update PO milestones without purchaseRequestId." });
                    setUpdating(null);
                    return;
                }
                const purchaseRequestRef = doc(db, 'purchaseRequests', request.purchaseRequestId);
                 const receivingMilestone: PurchaseStatus = {
                    stepId: 3, // Receiving And Sent To Location
                    status: 'completed',
                    completedAt: new Date().toISOString(),
                    completedBy: user.name,
                    itemName: itemToUpdate.itemName
                };
                batch.update(purchaseRequestRef, {
                    poMilestones: arrayUnion(receivingMilestone)
                });
            }
            
            const allItemsInCurrentInboundCompleted = items.every((item: InboundItem) => (item.inboundMilestones?.length || 0) === INBOUND_PROCESS_CONFIG.length);

            if (allItemsInCurrentInboundCompleted) {
                batch.update(requestRef, { 
                    status: 'Completed',
                    completedAt: new Date().toISOString(),
                    completedBy: user.name,
                });

                const purchaseRequestRef = doc(db, 'purchaseRequests', request.purchaseRequestId);
                batch.update(purchaseRequestRef, { status: 'Completed' });
                
                toast({
                    title: "Inbound Complete!",
                    description: `This PO (${request.id}) is now fully received.`,
                    duration: 5000,
                });

                const parentPurchaseRequestSnap = await getDoc(purchaseRequestRef);
                if (parentPurchaseRequestSnap.exists()) {
                    const parentPR = parentPurchaseRequestSnap.data() as PurchaseRequest;
                    const dealIdForQuery = parentPR.dealId;
                    
                    const allPrQuery = query(collection(db, 'purchaseRequests'), where('dealId', '==', dealIdForQuery));
                    const allPrSnapshot = await getDocs(allPrQuery);
                    const allPrDocs = allPrSnapshot.docs.map(d => d.data() as PurchaseRequest);

                    const allPrsForDealAreComplete = allPrDocs.every(pr => pr.status === 'Completed');
                    
                    if (allPrsForDealAreComplete) {
                        const o2dQuery = query(collection(db, "o2d"), where("dealId", "==", dealIdForQuery), limit(1));
                        const o2dSnapshot = await getDocs(o2dQuery);

                        if (!o2dSnapshot.empty) {
                            const o2dDocRef = o2dSnapshot.docs[0].ref;
                            const o2dData = (await getDoc(o2dDocRef)).data() as O2DProcess; // Re-fetch for latest data
                            const o2dStep = o2dData.milestones?.find(m => m.stepId === 7);

                            if (!o2dStep || o2dStep.status !== 'completed') {
                                const newMilestone: O2DStatus = {
                                    stepId: 7, 
                                    status: 'completed',
                                    completedAt: new Date().toISOString(),
                                    completedBy: "System (All Inbounds Complete)",
                                    remarks: "Automatically completed after all items for this deal were received.",
                                    selection: 'Done'
                                };
                                batch.update(o2dDocRef, { milestones: arrayUnion(newMilestone) });
                                    toast({
                                    title: "O2D Step 7 Completed!",
                                    description: `Purchase Material Receiving marked as done for deal ${o2dData.dealId}.`,
                                });
                            }
                        }
                    }
                }
            }
            await batch.commit();

        } catch (error) {
            console.error("Error updating inbound status:", error);
            toast({ variant: "destructive", title: "Update Failed", description: "Could not update the item process status." });
        } finally {
            setUpdating(null);
        }
    };
    
    const handleRevertUpdate = async () => {
        if (!request || !revertingMilestone || !user) return;

        const { itemIndex, milestone } = revertingMilestone;
        const key = `${itemIndex}-${milestone.stepId}`;
        setUpdating(key);

        try {
            const requestRef = doc(db, "inbounds", request.id);
            const items = [...(request.items || [])];
            const itemToUpdate = items[itemIndex];
            if (!itemToUpdate) throw new Error("Item not found");

            const wasLastStep = itemToUpdate.inboundMilestones?.length === INBOUND_PROCESS_CONFIG.length;
            
            itemToUpdate.inboundMilestones = itemToUpdate.inboundMilestones?.filter(m => m.stepId !== milestone.stepId);
            items[itemIndex] = itemToUpdate;
            
            await updateDoc(requestRef, { items: items });

            if (wasLastStep && itemToUpdate.poNumber) {
                const stockId = itemToUpdate.itemName.replace(/\//g, '-');
                const revertResult = await revertStockAdditionAction(stockId, itemToUpdate.poNumber, itemToUpdate.itemName, user.name);
                if (revertResult.success) {
                    toast({ title: 'Stock Reverted', description: revertResult.message });
                } else {
                    toast({ variant: 'destructive', title: 'Stock Revert Failed', description: revertResult.message });
                }
            }
            
            toast({ title: "Step Reverted", description: "The process step has been successfully reverted." });
        } catch (error: any) {
            console.error("Error reverting inbound status:", error);
            toast({ variant: "destructive", title: "Revert Failed", description: "Could not revert the item process status." });
        } finally {
            setUpdating(null);
            setRevertingMilestone(null);
        }
    };

    const handlePrint = () => {
        const printContent = document.getElementById('sticker-print-area-inbound');
        if (!printContent) return;
        const printWindow = window.open('', '_blank');
        if (!printWindow) return;
        printWindow.document.write('<html><head><title>Print Sticker</title></head><body>');
        printWindow.document.write(printContent.innerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        setTimeout(() => {
            printWindow.focus();
            printWindow.print();
        }, 250);
    };


    if (loading) {
        return (
            <div className="container mx-auto p-4 md:p-6 lg:p-8 space-y-4">
                <Skeleton className="h-10 w-48" />
                <Skeleton className="h-40 w-full" />
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
            </div>
        );
    }
    
    if (!request) {
        return (
             <div className="container mx-auto p-4 md:p-6 lg:p-8 text-center">
                <h1 className="text-2xl font-bold">Request not found</h1>
                <p className="text-muted-foreground">The request with ID {poNumber} could not be found.</p>
                <Button asChild variant="link" className="mt-4">
                    <Link href="/dashboard/inbound">Go Back</Link>
                </Button>
            </div>
        )
    }

    const items = request.items;
    const revertingStepConfig = revertingMilestone ? INBOUND_PROCESS_CONFIG.find(c => c.id === revertingMilestone.milestone.stepId) : null;

    return (
        <AlertDialog>
        <div className="container mx-auto p-4 md:p-6 lg:p-8">
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                    <Button asChild variant="outline" size="icon">
                        <Link href="/dashboard/inbound"><ArrowLeft /></Link>
                    </Button>
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight">Inbound Process</h1>
                        <p className="text-muted-foreground">Track receiving for PO: <span className="font-semibold text-primary">{request.id}</span> (Deal ID: {request.dealId})</p>
                    </div>
                </div>
                <Button asChild>
                    <Link href={`/dashboard/inbound/scan?dealId=${poNumber}`}>
                        <ScanLine className="mr-2 h-4 w-4" />
                        Scan Items
                    </Link>
                </Button>
            </div>

            <Card className="mb-6">
                <CardHeader>
                    <CardTitle>{request.customerName}</CardTitle>
                    <CardDescription>
                        Vendor: {request.vendor || 'Not set'}
                    </CardDescription>
                </CardHeader>
            </Card>

            <div className="space-y-4">
                <Card>
                    <CardHeader>
                        <CardTitle>Items to Process</CardTitle>
                    </CardHeader>
                    <CardContent>
                         <div className="space-y-4">
                            {(items || []).map((item, index) => {
                                const detail = item as any;
                                const name = detail.itemName;
                                const qty = detail.quantity;
                                const po = detail.poNumber;
                                const qtyUnit = 'Mtr';

                                return (
                                    <Collapsible key={index} asChild defaultOpen>
                                        <Card className="overflow-hidden">
                                            <div className="bg-muted/50 p-4 flex justify-between items-center">
                                                <div>
                                                    <p className="font-semibold">{name}</p>
                                                    <p className="text-sm text-muted-foreground">Qty: {qty} {qtyUnit}</p>
                                                </div>
                                                <div className="flex items-center gap-4">
                                                    <Badge variant="secondary">PO: {po || 'N/A'}</Badge>
                                                    <CollapsibleTrigger asChild>
                                                        <Button variant="ghost" size="sm">
                                                            View Process
                                                            <ChevronDown className="h-4 w-4 ml-2" />
                                                        </Button>
                                                    </CollapsibleTrigger>
                                                </div>
                                            </div>
                                            <CollapsibleContent>
                                                <ItemProcessTimeline
                                                    item={item}
                                                    itemIndex={index}
                                                    request={request}
                                                    onUpdate={handleStatusUpdate}
                                                    onRevert={(itemIndex, milestone) => setRevertingMilestone({itemIndex, milestone})}
                                                    userRole={role}
                                                    onBarcodeClick={(item, itemIndex, stepId) => {
                                                        setPrintingItem(item);
                                                        handleStatusUpdate(itemIndex, stepId);
                                                    }}
                                                />
                                            </CollapsibleContent>
                                        </Card>
                                    </Collapsible>
                                );
                            })}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
         {revertingMilestone && (
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                        This will revert the step: <strong>{revertingStepConfig?.name}</strong>. If this step triggered a stock update, the inventory will also be reverted. This action cannot be easily undone.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel onClick={() => setRevertingMilestone(null)}>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleRevertUpdate}>Continue</AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        )}
        <Dialog open={!!printingItem} onOpenChange={() => setPrintingItem(null)}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Print Sticker</DialogTitle>
                    <DialogDescription>
                        Sticker for {printingItem?.itemName} with length {printingItem?.quantity}.
                    </DialogDescription>
                </DialogHeader>
                {printingItem && (
                    <div id="sticker-print-area-inbound" className="py-4 flex justify-center">
                    <StockLengthSticker
                        bcn={printingItem.itemName}
                        length={parseFloat(printingItem.quantity)}
                        mrp={0} // MRP is not on the inbound item, would need to fetch from stock master
                        rack={'N/A'} // Rack is assigned later
                    />
                    </div>
                )}
                <DialogFooter>
                    <Button variant="ghost" onClick={() => setPrintingItem(null)}>Cancel</Button>
                    <Button onClick={handlePrint}>Print</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
        </AlertDialog>
    );
}

