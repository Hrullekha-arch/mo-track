

      "use client";

import * as React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { collection, onSnapshot, query, doc, getDoc, collectionGroup, runTransaction, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { DealVisit, Customer, Deal, User, SlotId, SlotSelection } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import Link from 'next/link';
import { AssignInstallerDialog } from "@/components/features/order-management/AssignInstallerDialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Eye, Plus, User as UserIcon, Calendar, ChevronDown, Share2, Copy, PlayCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";


interface EnrichedDealVisit extends DealVisit {
    customerName: string;
    dealName: string;
    dealDocId: string;
    customerId: string;
    customerAddress?: string;
    customer?: Customer | null;
}

const renderVisitStatus = (visit: EnrichedDealVisit) => {
    if (visit.status === 'completed') {
        return <Badge className="mt-1 bg-green-500">Completed</Badge>;
    }
    if (visit.visitStatus === 'Working') {
        return <Badge className="mt-1 bg-blue-500 animate-pulse">Working</Badge>;
    }
    if (visit.status === 'approved') {
        return <Badge className="mt-1" variant="secondary">Assigned</Badge>;
    }
    return <Badge className="mt-1" variant="outline">{visit.status || 'Pending'}</Badge>;
    
};



const InstallerCard = ({ 
  installer, 
  visits, 
  onAssign,
  onShare,
  onViewDetails
}: { 
  installer: User, 
  visits: EnrichedDealVisit[],
  onAssign: (visit: EnrichedDealVisit) => void;
  onShare: (visit: EnrichedDealVisit) => void;
  onViewDetails: (visit: EnrichedDealVisit) => void;
}) => {
    // Filter out completed visits - only show active/pending visits
    const activeVisits = visits.filter(visit => visit.status !== 'completed');

    return (
        <Collapsible defaultOpen={false}>
            <Card>
                <CollapsibleTrigger asChild>
                    <CardHeader className="flex flex-row items-center justify-between cursor-pointer hover:bg-muted/50">
                        <div className="flex items-center gap-4">
                            <Avatar>
                                <AvatarImage src={installer.avatarUrl || `https://ui-avatars.com/api/?name=${installer.name}`} />
                                <AvatarFallback>{installer.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                                <CardTitle>{installer.name}</CardTitle>
                                <CardDescription>{installer.email}</CardDescription>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <Badge variant={activeVisits.length > 0 ? "default" : "secondary"}>
                                {activeVisits.length} Active
                            </Badge>
                            <ChevronDown className="h-5 w-5" />
                        </div>
                    </CardHeader>
                </CollapsibleTrigger>
                <CollapsibleContent>
                    <CardContent className="pt-0">
                         <div className="space-y-3">
                            {activeVisits.length > 0 ? (
                                activeVisits.map(visit => (
                                    <Card 
                                        key={visit.id} 
                                        className={cn(
                                            "hover:shadow-md transition-shadow",
                                            visit.visitStatus === 'Working' && 'ring-2 ring-blue-500'
                                        )}
                                    >
                                        <CardContent className="p-4">
                                            {/* First Row: Customer Name and Status */}
                                            <div className="flex items-start justify-between mb-2">
                                                <div className="flex-1">
                                                    <h3 className="font-semibold text-lg">{visit.customerName}</h3>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Badge variant="outline" className="text-xs">
                                                        {visit.slotLabel || 'No Slot'}
                                                    </Badge>
                                                    {renderVisitStatus(visit)}
                                                </div>
                                            </div>

                                            {/* Second Row: Deal ID and Re-assign Button */}
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-2">
                                                    <Link 
                                                        href={`/dashboard/customers/${visit.customerId}/${visit.dealDocId}`} 
                                                        className="text-primary hover:underline font-medium"
                                                    >
                                                        {visit.dealId}
                                                    </Link>
                                                    {visit.dueDate && (
                                                        <span className="text-xs text-muted-foreground">
                                                            • {format(new Date(visit.dueDate), 'PPP')}
                                                        </span>
                                                    )}
                                                </div>
                                                <div className="flex items-center gap-1">
                                                    <Button 
                                                        size="sm" 
                                                        variant="ghost" 
                                                        onClick={() => onViewDetails(visit)}
                                                    >
                                                        <Eye className="h-4 w-4" />
                                                    </Button>
                                                    <Button 
                                                        size="sm" 
                                                        variant="outline" 
                                                        onClick={() => onAssign(visit)}
                                                    >
                                                        Re-Assign
                                                    </Button>
                                                    <Button 
                                                        size="sm" 
                                                        variant="ghost" 
                                                        onClick={() => onShare(visit)}
                                                    >
                                                        <Share2 className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                            </div>

                                            {/* Optional: Address if available */}
                                            {visit.customerAddress && (
                                                <p className="text-xs text-muted-foreground mt-2">
                                                    📍 {visit.customerAddress}
                                                </p>
                                            )}
                                        </CardContent>
                                    </Card>
                                ))
                            ) : (
                                <Card>
                                    <CardContent className="p-8 text-center">
                                        <p className="text-muted-foreground">No active visits assigned.</p>
                                    </CardContent>
                                </Card>
                            )}
                        </div>

                    </CardContent>
                </CollapsibleContent>
            </Card>
        </Collapsible>
    )
}


function AllVisitsTable({ visits, onAssign, onShare, onViewDetails }: { visits: EnrichedDealVisit[], onAssign: (visit: EnrichedDealVisit) => void, onShare: (visit: EnrichedDealVisit) => void, onViewDetails: (visit: EnrichedDealVisit) => void }) {
    return (
        <Card>
            <CardHeader>
                <CardTitle>All Visits List</CardTitle>
                <CardDescription>A comprehensive list of all scheduled visits.</CardDescription>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Customer</TableHead>
                            <TableHead>Deal ID</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Date & Slot</TableHead>
                            <TableHead>Assigned To</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Created By</TableHead>
                            <TableHead>Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {visits.map(visit => (
                            <TableRow key={visit.id} className={cn(visit.visitStatus === 'Working' && 'ring-2 ring-blue-500 ring-offset-2')}>
                                <TableCell className="font-medium">{visit.customerName}</TableCell>
                                <TableCell>
                                    <Link href={`/dashboard/customers/${visit.customerId}/${visit.dealDocId}`} className="text-primary hover:underline">
                                        {visit.dealId}
                                    </Link>
                                </TableCell>
                                <TableCell>
                                    <Badge variant="outline" className="capitalize">{visit.typeOfVisit}</Badge>
                                </TableCell>
                                <TableCell>
                                    {visit.dueDate ? format(new Date(visit.dueDate), 'PPP') : 'Not Set'}
                                    <br />
                                    <span className="text-xs text-muted-foreground">{visit.slotLabel || 'N/A'}</span>
                                </TableCell>
                                <TableCell>{visit.assignedTo ? (visits.find(u => u.id === visit.assignedTo)?.createdBy || 'N/A') : 'Unassigned'}</TableCell>
                                <TableCell>{renderVisitStatus(visit)}</TableCell>
                                <TableCell>{visit.createdBy}</TableCell>
                                <TableCell className="flex gap-1">
                                    <Button size="sm" variant="ghost" onClick={() => onViewDetails(visit)}><Eye className="h-4 w-4" /></Button>
                                    <Button size="sm" variant="ghost" onClick={() => onAssign(visit)}>Assign</Button>
                                    <Button size="sm" variant="ghost" onClick={() => onShare(visit)}><Share2 className="h-4 w-4" /></Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}


export default function AllVisitsPage() {
    const [allVisits, setAllVisits] = React.useState<EnrichedDealVisit[]>([]);
    const [users, setUsers] = React.useState<User[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [selectedVisit, setSelectedVisit] = React.useState<EnrichedDealVisit | null>(null);
    const [isAssigning, setIsAssigning] = React.useState(false);
    const [shareableLink, setShareableLink] = React.useState<string | null>(null);
    const [detailsVisit, setDetailsVisit] = React.useState<EnrichedDealVisit | null>(null);

    const { toast } = useToast();
    
    const installers = React.useMemo(() => users.filter(u => u.role === 'installer'), [users]);

    const groupedVisits = React.useMemo(() => {
        const map = new Map<string, EnrichedDealVisit[]>();
        installers.forEach(installer => map.set(installer.id, [])); // Initialize for all installers
        allVisits.forEach(visit => {
            if (visit.assignedTo) {
                if (!map.has(visit.assignedTo)) {
                    map.set(visit.assignedTo, []);
                }
                map.get(visit.assignedTo)!.push(visit);
            }
        });
        return map;
    }, [allVisits, installers]);

    React.useEffect(() => {
        setLoading(true);

        const usersQuery = query(collection(db, "users"));
        const unsubscribeUsers = onSnapshot(usersQuery, (snapshot) => {
            const usersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User));
            setUsers(usersData);
        });

        const visitsQuery = collectionGroup(db, 'visits');
        const unsubscribeVisits = onSnapshot(visitsQuery, async (snapshot) => {
            const customerCache = new Map<string, Customer>();
            const dealCache = new Map<string, Deal>();

            const visitsDataPromises = snapshot.docs.map(async (docSnap) => {
                const visit = docSnap.data() as DealVisit;
                const pathParts = docSnap.ref.path.split('/');
                const customerId = pathParts[1];
                const dealDocId = pathParts[3];

                let customerName = 'Unknown';
                let dealName = 'Unknown';
                let dealId = 'N/A';
                
                if (!customerCache.has(customerId)) {
                    const customerRef = doc(db, 'customers', customerId);
                    const customerSnap = await getDoc(customerRef);
                    if (customerSnap.exists()) {
                        customerCache.set(customerId, { id: customerSnap.id, ...customerSnap.data() } as Customer);
                    }
                }
                customerName = customerCache.get(customerId)?.name || 'Unknown';
                
                const dealCacheKey = `${customerId}-${dealDocId}`;
                if (!dealCache.has(dealCacheKey)) {
                     const dealRef = doc(db, 'customers', customerId, 'deals', dealDocId);
                     const dealSnap = await getDoc(dealRef);
                     if (dealSnap.exists()) {
                        dealCache.set(dealCacheKey, { id: dealSnap.id, ...dealSnap.data() } as Deal);
                    }
                }
                const dealData = dealCache.get(dealCacheKey);
                dealName = dealData?.dealName || 'Unknown';
                dealId = dealData?.dealId || 'N/A';

                return { ...visit, id: docSnap.id, customerId, dealDocId, customerName, dealName, dealId, customer: customerCache.get(customerId) || null };
            });
            
            const visitsData = await Promise.all(visitsDataPromises);
            setAllVisits(visitsData);
            setLoading(false);
        });

        return () => {
            unsubscribeUsers();
            unsubscribeVisits();
        };
    }, []);

    const handleShareClick = (visit: EnrichedDealVisit) => {
        const baseURL = "https://mo-track-yerq.vercel.app";
        const link = `${baseURL}/visit/confirm/${visit.id}?customerId=${visit.customerId}&dealId=${visit.dealDocId}`;
        setShareableLink(link);
    };

    const handleAssignInstaller = async (installerId: string, slot?: SlotSelection) => {
        if (!selectedVisit || !slot || !slot.slotDate) return;
        setIsAssigning(false); // To close the dialog immediately

        try {
            await runTransaction(db, async (transaction) => {
                const visitRef = doc(db, "customers", selectedVisit.customerId, "deals", selectedVisit.dealDocId, "visits", selectedVisit.id);
                
                transaction.update(visitRef, {
                    assignedTo: installerId,
                    slotDate: slot.slotDate,
                    slotId: slot.slotId,
                    slotLabel: slot.slotLabel,
                    slotStart: slot.slotStart,
                    slotEnd: slot.slotEnd,
                    assignedAt: new Date().toISOString(),
                });
            });

            toast({ title: "Assigned", description: "Installer and slot updated successfully." });
            setSelectedVisit(null);
        } catch (error: any) {
            console.error("Failed to assign installer:", error);
            toast({ variant: "destructive", title: "Assignment Failed", description: error?.message || "Could not save slot." });
        }
    };
    
    if (loading) {
        return <div className="p-8"><Skeleton className="h-64 w-full" /></div>;
    }

    return (
        <div className="p-4 md:p-6 lg:p-8 space-y-6">
            <header className="flex items-start justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">All Visits</h1>
                    <p className="text-muted-foreground">A centralized log of all customer visits and appointments.</p>
                </div>
            </header>
            
            <Tabs defaultValue="all" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="all">All Visits</TabsTrigger>
                </TabsList>
                <TabsContent value="installers" className="mt-4">
                     <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-4">
                        {installers.map(installer => (
                            <InstallerCard
                                key={installer.id}
                                installer={installer}
                                visits={groupedVisits.get(installer.id) || []}
                                onAssign={(visit) => { setSelectedVisit(visit); setIsAssigning(true); }}
                                onShare={handleShareClick}
                                onViewDetails={(visit) => setDetailsVisit(visit)}
                            />
                        ))}
                    </div>
                </TabsContent>
                <TabsContent value="all" className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-4">
                        {installers.map(installer => (
                            <InstallerCard
                                key={installer.id}
                                installer={installer}
                                visits={groupedVisits.get(installer.id) || []}
                                onAssign={(visit) => { setSelectedVisit(visit); setIsAssigning(true); }}
                                onShare={handleShareClick}
                                onViewDetails={(visit) => setDetailsVisit(visit)}
                            />
                        ))}
                    </div>
                    <div>
                        <AllVisitsTable
                            visits={allVisits}
                            onAssign={(visit) => { setSelectedVisit(visit); setIsAssigning(true); }}
                            onShare={handleShareClick}
                            onViewDetails={(visit) => setDetailsVisit(visit)}
                        />
                    </div>
                </TabsContent>
            </Tabs>
            
            <Dialog open={!!detailsVisit} onOpenChange={() => setDetailsVisit(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Visit Details</DialogTitle>
                    </DialogHeader>
                    {detailsVisit && (
                        <div className="py-4 space-y-4">
                            <p><strong>Type:</strong> <Badge variant="outline" className="capitalize">{detailsVisit.typeOfVisit}</Badge></p>
                            {detailsVisit.typeOfVisit === 'measurement' ? (
                                <div className="space-y-2">
                                    <h4 className="font-semibold">Measurement Details:</h4>
                                    <p>Measurements: {detailsVisit.measurements?.join(', ') || 'N/A'}</p>
                                    {detailsVisit.blinds && <p>Blinds: {detailsVisit.blinds.join(', ')}</p>}
                                </div>
                            ) : (
                                 <div className="space-y-2">
                                    <h4 className="font-semibold">Delivery/Installation Details:</h4>
                                     <p>Items: {detailsVisit.deliveryInstallations?.map(d => `${d?.id} (x${d?.noOfPcs || 1})`).join(', ') || 'N/A'}</p>
                                </div>
                            )}
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            <AssignInstallerDialog
                isOpen={isAssigning}
                onClose={() => setIsAssigning(false)}
                onAssign={handleAssignInstaller}
                installers={installers}
                currentInstallerId={selectedVisit?.assignedTo}
                currentVisitId={selectedVisit?.id}
                currentSlotSelection={selectedVisit ? { 
                    slotDate: selectedVisit.slotDate, 
                    slotId: selectedVisit.slotId as SlotId, 
                    slotLabel: selectedVisit.slotLabel,
                    slotStart: selectedVisit.slotStart,
                    slotEnd: selectedVisit.slotEnd,
                } : undefined}
            />

            <Dialog open={!!shareableLink} onOpenChange={() => setShareableLink(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Share Confirmation Link</DialogTitle>
                    </DialogHeader>
                    <div className="py-4">
                        <Input value={shareableLink || ""} readOnly />
                    </div>
                    <DialogFooter>
                        <Button onClick={() => { navigator.clipboard.writeText(shareableLink || ""); toast({title: "Link Copied!"}); }}>
                            <Copy className="mr-2 h-4 w-4"/> Copy Link
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}


    
