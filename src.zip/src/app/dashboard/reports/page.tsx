
"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableFooter } from "@/components/ui/table";
import { DollarSign, ShoppingCart, Users, TrendingUp, Package, Star, BarChart, AlertTriangle, ArrowRight, TrendingDown, Sparkles, LineChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DateRangePicker } from "@/components/ui/date-range-picker";
import { BarChart as RechartsBarChart, LineChart as RechartsLineChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { useState, useEffect, useMemo } from "react";
import { DateRange } from "react-day-picker";
import { getReportData, SalesPerformanceData, ProfitLossData, StockAnalysisData, Order, StockTransaction } from "./actions";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ReportDetailDialog } from "@/components/features/reports/ReportDetailDialog";

const formatToINR = (value: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);


export default function ReportsPage() {
    const [dateRange, setDateRange] = useState<DateRange | undefined>();
    const [orders, setOrders] = useState<Order[]>([]);
    const [salesPerformance, setSalesPerformance] = useState<SalesPerformanceData[]>([]);
    const [profitLoss, setProfitLoss] = useState<ProfitLossData[]>([]);
    const [stockAnalysis, setStockAnalysis] = useState<StockAnalysisData>({ topSellingProducts: [], deadStock: []});
    const [stockLedger, setStockLedger] = useState<StockTransaction[]>([]);
    const [loading, setLoading] = useState(true);
    const [detailView, setDetailView] = useState<{ type: string | null, payload?: any }>({ type: null });
    const { toast } = useToast();

    useEffect(() => {
        const fetchAllReports = async () => {
            setLoading(true);
            try {
                const [salesData, profitData, stockData, orderData, ledgerData] = await Promise.all([
                    getReportData({ reportType: 'sales-performance', dateRange }),
                    getReportData({ reportType: 'profit-loss', dateRange }),
                    getReportData({ reportType: 'stock-analysis', dateRange }),
                    getReportData({ reportType: 'order-summary', dateRange }),
                    getReportData({ reportType: 'stock-ledger', dateRange }),
                ]);
                
                setSalesPerformance(salesData.salesPerformance || []);
                setProfitLoss(profitData.profitLoss || []);
                setStockAnalysis(stockData.stockAnalysis || { topSellingProducts: [], deadStock: [] });
                setOrders(orderData.orders || []);
                setStockLedger(ledgerData.stockLedger || []);

            } catch (error) {
                toast({
                    variant: "destructive",
                    title: "Error loading reports",
                    description: "Could not fetch all report data.",
                });
            } finally {
                setLoading(false);
            }
        };

        fetchAllReports();
    }, [dateRange, toast]);
    
    const totalSales = salesPerformance.reduce((acc, curr) => acc + curr.totalValue, 0);
    const totalProfit = profitLoss.reduce((acc, curr) => acc + curr.profit, 0);
    const avgMargin = totalSales > 0 ? (totalProfit / totalSales) * 100 : 0;
    const totalTransactions = salesPerformance.reduce((acc, curr) => acc + curr.totalOrders, 0);
    const avgBasketSize = totalTransactions > 0 ? totalSales / totalTransactions : 0;
    
    const actionableInsights = useMemo(() => {
        const insights = [];
        if (stockAnalysis.topSellingProducts.length > 0) {
            const topProduct = stockAnalysis.topSellingProducts[0];
            insights.push(`Restock high-demand items like ${topProduct.name} immediately.`);
        }
        if (stockAnalysis.deadStock.length > 0) {
            const deadItem = stockAnalysis.deadStock[0];
            insights.push(`Offer a promotion on Dead Stock items like ${deadItem.name} to clear inventory.`);
        }
        if (salesPerformance.length > 0) {
            const topSalesman = salesPerformance[0];
            insights.push(`Reward or incentivize top-performing salesman: ${topSalesman.salesman}.`);
        }
        const lowMarginOrder = profitLoss.filter(p => p.totalAmount > 0).sort((a,b) => (a.profit / a.totalAmount) - (b.profit / b.totalAmount))[0];
        if(lowMarginOrder) {
            insights.push(`Adjust pricing for products in Order #${lowMarginOrder.orderId} to improve low margins.`);
        }
        return insights;
    }, [stockAnalysis, salesPerformance, profitLoss]);

     const salesTrendData = useMemo(() => {
        const salesByDate: Record<string, Record<string, number>> = {};
        const salesmen = new Set<string>();

        orders.forEach(order => {
            const date = format(new Date(order.createdAt), 'yyyy-MM-dd');
            const salesman = order.salesPerson || 'Unknown';
            salesmen.add(salesman);
            if (!salesByDate[date]) {
                salesByDate[date] = {};
            }
            salesByDate[date][salesman] = (salesByDate[date][salesman] || 0) + (order.totalAmount || 0);
        });

        const sortedDates = Object.keys(salesByDate).sort();
        
        return sortedDates.map(date => {
            const entry: Record<string, any> = { date: format(new Date(date), 'dd MMM') };
            let total = 0;
            salesmen.forEach(s => {
                const sale = salesByDate[date][s] || 0;
                entry[s] = sale;
                total += sale;
            });
            entry.total = total;
            return entry;
        });

    }, [orders]);
    
    const salesmenForChart = [...new Set(orders.map(o => o.salesPerson || 'Unknown'))];
    const chartColors = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#0088FE', '#00C49F'];

    const getDetailDialogContent = () => {
        switch (detailView.type) {
            case 'totalSales':
            case 'avgBasketSize':
                return {
                    title: 'Total Sales Details',
                    description: `A list of all ${orders.length} orders contributing to the total sales amount.`,
                    data: orders,
                    columns: [
                        { accessorKey: 'crmOrderNo', header: 'Order No' },
                        { accessorKey: 'createdAt', header: 'Date', cell: (row: Order) => format(new Date(row.createdAt), 'PPP') },
                        { accessorKey: 'customerName', header: 'Customer Name' },
                        { accessorKey: 'customerPhone', header: 'Phone' },
                        { accessorKey: 'salesPerson', header: 'Salesman' },
                        { accessorKey: 'storeName', header: 'Store' },
                        { accessorKey: 'totalAmount', header: 'Amount', cell: (row: Order) => formatToINR(row.totalAmount || 0) },
                    ],
                    footer: (
                        <div className="flex justify-end gap-8 font-semibold">
                            <span>Total Orders: {orders.length}</span>
                            <span>Total Value: {formatToINR(totalSales)}</span>
                        </div>
                    )
                };
            case 'totalProfit':
            case 'avgMargin':
                 return {
                    title: 'Profit & Loss Details',
                    description: `A breakdown of profit for each of the ${profitLoss.length} orders.`,
                    data: profitLoss,
                    columns: [
                        { accessorKey: 'orderId', header: 'Order No' },
                        { accessorKey: 'orderDate', header: 'Date', cell: (row: ProfitLossData) => format(new Date(row.orderDate), 'PPP') },
                        { accessorKey: 'customerName', header: 'Customer' },
                        { accessorKey: 'salesPerson', header: 'Salesman' },
                        { accessorKey: 'totalAmount', header: 'Sale Amount', cell: (row: ProfitLossData) => formatToINR(row.totalAmount) },
                        { accessorKey: 'costOfGoods', header: 'COGS', cell: (row: ProfitLossData) => formatToINR(row.costOfGoods) },
                        { accessorKey: 'profit', header: 'Profit', cell: (row: ProfitLossData) => formatToINR(row.profit) },
                    ],
                    footer: (
                        <div className="flex justify-end gap-8 font-semibold">
                            <span>Total Profit: {formatToINR(totalProfit)}</span>
                        </div>
                    )
                };
            case 'salesmanPerformance': {
                const salesman = detailView.payload.salesman;
                const salesmanOrders = orders.filter(o => o.salesPerson === salesman);
                const totalSalesmanValue = salesmanOrders.reduce((acc, o) => acc + (o.totalAmount || 0), 0);
                return {
                    title: `Sales Details for ${salesman}`,
                    description: `All orders attributed to ${salesman}.`,
                    data: salesmanOrders,
                    columns: [
                        { accessorKey: 'crmOrderNo', header: 'Order No' },
                        { accessorKey: 'createdAt', header: 'Date', cell: (row: Order) => format(new Date(row.createdAt), 'PPP') },
                        { accessorKey: 'customerName', header: 'Customer Name' },
                        { accessorKey: 'totalAmount', header: 'Amount', cell: (row: Order) => formatToINR(row.totalAmount || 0) },
                    ],
                     footer: (
                        <div className="flex justify-end gap-8 font-semibold">
                            <span>Total Orders: {salesmanOrders.length}</span>
                            <span>Total Value: {formatToINR(totalSalesmanValue)}</span>
                        </div>
                    )
                };
            }
             case 'topSelling': {
                const bcn = detailView.payload.name;
                const filteredTransactions = stockLedger.filter(tx => tx.bcn === bcn && tx.type === 'deduction');
                return {
                    title: `Transaction History for ${bcn}`,
                    description: `Showing all sales transactions for this product.`,
                    data: filteredTransactions,
                    columns: [
                        { accessorKey: 'createdAt', header: 'Date', cell: (row: StockTransaction) => format(new Date(row.createdAt), 'PPP p') },
                        { accessorKey: 'orderId', header: 'Order ID' },
                        { accessorKey: 'createdBy', header: 'User' },
                        { accessorKey: 'quantityChange', header: 'Qty Sold', cell: (row: StockTransaction) => Math.abs(row.quantityChange).toFixed(2) },
                    ],
                    footer: (
                        <div className="flex justify-end gap-8 font-semibold">
                            <span>Total Units Sold: {filteredTransactions.reduce((acc, tx) => acc + Math.abs(tx.quantityChange), 0).toFixed(2)}</span>
                        </div>
                    )
                };
             }
             case 'deadStock': {
                const bcn = detailView.payload.name;
                const filteredTransactions = stockLedger.filter(tx => tx.bcn === bcn);
                return {
                    title: `Transaction History for ${bcn}`,
                    description: `Showing all purchase and sales transactions for this product.`,
                    data: filteredTransactions,
                    columns: [
                        { accessorKey: 'type', header: 'Type', cell: (row: StockTransaction) => <Badge variant={row.type === 'addition' ? 'default' : 'secondary'} className={row.type === 'addition' ? 'bg-green-600' : 'bg-red-600'}>{row.type}</Badge>},
                        { accessorKey: 'createdAt', header: 'Date', cell: (row: StockTransaction) => format(new Date(row.createdAt), 'PPP p') },
                        { accessorKey: 'orderId', header: 'Reference ID', cell: (row: StockTransaction) => row.orderId || row.poNumber || 'N/A' },
                        { accessorKey: 'createdBy', header: 'User' },
                        { accessorKey: 'quantityChange', header: 'Qty Changed', cell: (row: StockTransaction) => row.quantityChange.toFixed(2) },
                    ],
                    footer: (
                        <div className="flex justify-end gap-8 font-semibold">
                            <span>Total Transactions: {filteredTransactions.length}</span>
                        </div>
                    )
                };
             }
            default:
                return null;
        }
    };
    
    const detailContent = getDetailDialogContent();

    return (
        <>
        <div className="container mx-auto p-4 md:p-6 lg:p-8">
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Retail Business Report</h1>
                    <p className="text-muted-foreground">A complete overview of your business performance.</p>
                </div>
                <div>
                    <DateRangePicker date={dateRange} onDateChange={setDateRange} />
                </div>
            </div>

             <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                <Card className="col-span-1 lg:col-span-2">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><DollarSign /> Sales Overview</CardTitle>
                    </CardHeader>
                    <CardContent className="grid grid-cols-2 gap-4">
                        <button onClick={() => setDetailView({ type: 'totalSales' })} className="p-4 rounded-lg bg-muted text-left hover:bg-muted/80 transition-colors">
                            <p className="text-sm text-muted-foreground">Total Sales</p>
                            {loading ? <Skeleton className="h-7 w-24 mt-1" /> : <p className="text-2xl font-bold">{formatToINR(totalSales)}</p>}
                        </button>
                         <button onClick={() => setDetailView({ type: 'totalProfit' })} className="p-4 rounded-lg bg-muted text-left hover:bg-muted/80 transition-colors">
                            <p className="text-sm text-muted-foreground">Net Profit</p>
                            {loading ? <Skeleton className="h-7 w-24 mt-1" /> : <p className="text-2xl font-bold text-green-600">{formatToINR(totalProfit)}</p>}
                        </button>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><TrendingUp /> Profitability</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {loading ? <Skeleton className="h-10 w-3/4" /> : (
                            <button onClick={() => setDetailView({ type: 'avgMargin' })} className="w-full text-left">
                                <p className="text-sm text-muted-foreground">Avg. Margin %</p>
                                <p className="text-2xl font-bold">{avgMargin.toFixed(2)}%</p>
                            </button>
                        )}
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Users /> Customer Insights</CardTitle>
                    </CardHeader>
                    <CardContent>
                         {loading ? <Skeleton className="h-10 w-3/4" /> : (
                            <button onClick={() => setDetailView({ type: 'avgBasketSize' })} className="w-full text-left">
                                <p className="text-sm text-muted-foreground">Avg. Basket Size</p>
                                <p className="text-2xl font-bold">{formatToINR(avgBasketSize)}</p>
                            </button>
                        )}
                    </CardContent>
                </Card>
            </div>
            
             <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mt-6">
                <Card className="lg:col-span-2">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Star/> Salesman Performance</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {loading ? <Skeleton className="h-[300px] w-full" /> : (
                             <ResponsiveContainer width="100%" height={300}>
                                <RechartsBarChart data={salesPerformance}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="salesman" fontSize={12} tickLine={false} axisLine={false} />
                                    <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `₹${Number(value)/1000}k`}/>
                                    <Tooltip formatter={(value) => formatToINR(value as number)} />
                                    <Legend />
                                    <Bar dataKey="totalValue" name="Total Sales" radius={[4, 4, 0, 0]} onClick={(data) => setDetailView({ type: 'salesmanPerformance', payload: data })}>
                                         {salesPerformance.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={'hsl(var(--chart-1))'} />
                                        ))}
                                    </Bar>
                                </RechartsBarChart>
                            </ResponsiveContainer>
                        )}
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Package/> Stock & Inventory</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                         {loading ? <Skeleton className="h-40 w-full" /> : (
                             <>
                            <div>
                                <h4 className="font-semibold mb-2">Top Selling Products</h4>
                                <Table>
                                    <TableHeader>
                                        <TableRow><TableHead>Product</TableHead><TableHead className="text-right">Volume</TableHead></TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {stockAnalysis.topSellingProducts.map(p => (
                                            <TableRow key={p.name} className="cursor-pointer hover:bg-muted" onClick={() => setDetailView({ type: 'topSelling', payload: p })}><TableCell>{p.name}</TableCell><TableCell className="text-right">{p.volume.toFixed(2)}</TableCell></TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </div>
                            <div>
                                <h4 className="font-semibold mb-2 flex items-center gap-2 text-destructive"><AlertTriangle/> Dead Stock</h4>
                                <Table>
                                    <TableHeader>
                                        <TableRow><TableHead>Product</TableHead><TableHead className="text-right">Age</TableHead></TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {stockAnalysis.deadStock.map(p => (
                                            <TableRow key={p.name} className="cursor-pointer hover:bg-muted" onClick={() => setDetailView({ type: 'deadStock', payload: p })}><TableCell>{p.name}</TableCell><TableCell className="text-right">{p.age}</TableCell></TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </div>
                            </>
                         )}
                    </CardContent>
                </Card>
            </div>

            <Card className="mt-6">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><LineChart /> Daily Sales Trend</CardTitle>
                </CardHeader>
                <CardContent>
                    {loading ? <Skeleton className="h-[350px] w-full" /> : (
                        <ResponsiveContainer width="100%" height={350}>
                            <RechartsLineChart data={salesTrendData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="date" fontSize={12} tickLine={false} axisLine={false} />
                                <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `₹${Number(value)/1000}k`} />
                                <Tooltip formatter={(value) => formatToINR(value as number)} />
                                <Legend />
                                <Line type="monotone" dataKey="total" strokeWidth={2} name="Total Sales" />
                                {salesmenForChart.map((s, i) => (
                                    <Line key={s} type="monotone" dataKey={s} stroke={chartColors[i % chartColors.length]} strokeWidth={2} name={s} />
                                ))}
                            </RechartsLineChart>
                        </ResponsiveContainer>
                    )}
                </CardContent>
            </Card>
            
             <Card className="mt-6">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><BarChart/> Comparative Trends</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-3 gap-6">
                     <div className="flex items-center gap-4 p-4 rounded-lg bg-muted">
                        <TrendingUp className="h-8 w-8 text-green-500"/>
                        <div>
                            <p className="text-sm text-muted-foreground">Month-over-Month Growth</p>
                            <p className="text-xl font-bold">+12.5%</p>
                        </div>
                    </div>
                     <div className="flex items-center gap-4 p-4 rounded-lg bg-muted">
                        <TrendingUp className="h-8 w-8 text-green-500"/>
                        <div>
                            <p className="text-sm text-muted-foreground">Year-over-Year Growth</p>
                            <p className="text-xl font-bold">+8.2%</p>
                        </div>
                    </div>
                     <div className="flex items-center gap-4 p-4 rounded-lg bg-muted">
                        <TrendingDown className="h-8 w-8 text-red-500"/>
                        <div>
                            <p className="text-sm text-muted-foreground">Return Rate</p>
                            <p className="text-xl font-bold">1.8%</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card className="mt-6 bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-700">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-blue-800 dark:text-blue-300"><Sparkles/> Actionable Insights</CardTitle>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="space-y-2">
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-4 w-full" />
                            <Skeleton className="h-4 w-2/3" />
                        </div>
                    ) : (
                        <ul className="list-disc list-inside space-y-2 text-blue-700 dark:text-blue-400">
                            {actionableInsights.length > 0 ? (
                                actionableInsights.map((insight, index) => (
                                    <li key={index}>{insight}</li>
                                ))
                            ) : (
                                <li>No specific insights to show based on the current data.</li>
                            )}
                        </ul>
                    )}
                </CardContent>
            </Card>
        </div>
        {detailContent && (
             <ReportDetailDialog
                isOpen={!!detailView.type}
                onClose={() => setDetailView({ type: null })}
                title={detailContent.title}
                description={detailContent.description}
                data={detailContent.data}
                columns={detailContent.columns}
                footer={detailContent.footer}
            />
        )}
        </>
    );
}

    